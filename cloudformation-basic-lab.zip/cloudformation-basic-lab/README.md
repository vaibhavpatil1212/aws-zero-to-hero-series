# CloudFormation Basic Lab

This project contains basic AWS CloudFormation templates to create an S3 bucket and an EC2 instance.

## Files

- `templates/s3-bucket.yaml`: CloudFormation template for an S3 bucket
- `templates/ec2-instance.yaml`: CloudFormation template for an EC2 instance
- `README.md`: Project description

## How to Use

1. Open AWS CloudFormation Console.
2. Upload the desired template file.
3. Deploy the stack.
